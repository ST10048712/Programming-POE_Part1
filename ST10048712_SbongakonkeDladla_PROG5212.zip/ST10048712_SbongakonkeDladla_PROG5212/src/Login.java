import java.util.Scanner;

public class Login {

       
     public boolean checkUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        String regex = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\\$%\\^&\\*]).{8,}$";
        return password.matches(regex);
    }

    public String registerUser(String username, String password, String firstName, String lastName) {
        if (!checkUsername(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.";
        }
        // Registration successful
        return "User successfully registered!";
    }

    public boolean loginUser(String username, String password) {
        // Example hard-coded credentials for demonstration purposes
        return username.equals("dev_1") && password.equals("P@ssw0rd");
    }

    public String returnLoginStatus(boolean loginSuccessful, String firstName, String lastName) {
        if (loginSuccessful) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        // Prompt the user for registration details
        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Create a username: ");
        String username = scanner.nextLine();

        System.out.print("Create a password: ");
        String password = scanner.nextLine();

        // Register the user
        String registerMessage = login.registerUser(username, password, firstName, lastName);
        System.out.println(registerMessage);

        // If registration was successful, prompt for login
        if (registerMessage.equals("User successfully registered!")) {
            System.out.print("Enter your username to login: ");
            String loginUsername = scanner.nextLine();

            System.out.print("Enter your password to login: ");
            String loginPassword = scanner.nextLine();

            // Check login credentials
            boolean loginSuccessful = login.loginUser(loginUsername, loginPassword);
            String loginStatus = login.returnLoginStatus(loginSuccessful, firstName, lastName);
            System.out.println(loginStatus);
        }

        // Close the scanner to prevent resource leaks
        scanner.close();
    }
}












